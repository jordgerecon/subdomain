
# Mass Account Takeovers-Credentials Stuffing /Sensitive Information Leaks lead to ATO

## Hunter contact

* Email: suzushah3509@gmail.com
* GPG:

```

```

## Vulnerability Summary

* Product:         https://lokalise.com/
* CVSS:            CVSS:3.0/AV:L/AC:H/PR:N/UI:R/S:U/C:H/I:N/A:H (6.3)
* Bug type:        improper-access-control-generic-cwe-284
* Endpoint:        https://lokalise.com/
* Vulnerable part: others
* Part name:       https://lokalise.com/
* Payload:         https://lokalise.com/
* Tech. environ.:  Firefox
* CVE:             CVE-2025-12122
* Impact:          Account Takeover

## Vulnerability Description

Description:-
A mass data leak via public resourced vulnerability refers to a situation where a significant amount of sensitive or private information is exposed or leaked due to a vulnerability in databases, APIs(Application Programming Interfaces),cloud storage and other online platforms that are accessible to the general public. it can have severe consequences, including the exposures of personal information,financial data,intellectual property, and more. it can lead to privacy breaches , identity theft, financial loss, reputational damage for individuals and organizations and legal repercussions. While conducting our reconnaissance, we came across multiple sets of user's working credentials and confidentials documents for the domains``https://lokalise.com/" These findings were sourced from publicly accessible platforms such as https://breachforums.st. This acquired data provides us with the means to illicitly enter user accounts,exfiltrate user information and execute delicate actions on their behalf without proper authorization.

Observation:-
This vulnerability has the potential for extended exploitation, allowing malicious actors to execute sensitive actions on the victim's behalf and discovered additional vulnerabilities that could harm the system.

STEP TO REPRODUCE :-
Go to this Telegram bot "https://t.me/Breach_Forums_Bot".
Input the domain "https://lokalise.com/" into the telegram bot and then press the submit button.
Note that credentials for the users such as email address and password and discovered.
Launch your web site on this telegram bot and navigate to the address "https://lokalise.com/"
Provide the credentials and click the sign-in button.
Observe that by using valid credentials, you are able to gain control of the victim's account.

All Credentials are uploaded on my google drive here is the link:
https://drive.google.com/drive/folders/18WDRpMh3qVD4HYDmeRSfQiPxdDLsx6pq?usp=sharing

